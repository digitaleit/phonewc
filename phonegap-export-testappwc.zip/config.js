define( function ( require ) {

	"use strict";

	return {
		app_slug : 'testappwc',
		wp_ws_url : 'https://www.web-coaching.it/wp-appkit-api/testappwc',
		wp_url : 'https://www.web-coaching.it',
		theme : 'q-ios',
		version : '0.0.1',
		app_title : '',
		app_platform : 'ios',
		gmt_offset : 1,
		debug_mode : 'off',
		auth_key : '4bbR[-Ta6Gg01eq6|w =5q#e+=e(Fh=a6{#?Y4E!0y`R!B_y8{._0;RQhT>|5}6{',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
